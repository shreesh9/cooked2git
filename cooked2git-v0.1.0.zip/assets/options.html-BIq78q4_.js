import"./retro-BJQaUule.js";import{a as f,b as h,d as I,S as u}from"./storage-VD2-ITkR.js";document.addEventListener("DOMContentLoaded",async()=>{const s=document.getElementById("saveConfigBtn"),c=document.getElementById("verifyZeroTrustBtn"),l=document.getElementById("nukeBtn"),a=document.getElementById("ledgerTableBody");try{const e=await f();e.repoOwner&&(document.getElementById("repoOwnerInput").value=e.repoOwner),e.repoName&&(document.getElementById("repoNameInput").value=e.repoName),e.branch&&(document.getElementById("branchInput").value=e.branch)}catch(e){console.warn("[Cooked2Git Options] Could not load config:",e)}d(),s==null||s.addEventListener("click",async()=>{const e=document.getElementById("patInput").value,o=document.getElementById("repoOwnerInput").value,r=document.getElementById("repoNameInput").value,t=document.getElementById("branchInput").value||"main";if(!e||!o||!r){alert("Please fill in PAT, repository owner, and repository name.");return}await h({pat:e,repoOwner:o,repoName:r,branch:t}),alert("Configuration saved securely in chrome.storage.local."),d()}),c==null||c.addEventListener("click",()=>{alert(`Zero-Trust Audit Result:

`+["✓ All requests go directly to api.github.com","✓ No external telemetry or relay servers","✓ Tokens stored in chrome.storage.local only","✓ CSP: script-src 'self' — no remote code execution","✓ No data sent to cooked2git servers (none exist)"].join(`
`))}),l==null||l.addEventListener("click",async()=>{confirm(`⚠️ NUKE ALL DATA?

This will permanently delete:
• GitHub PAT token
• All extension settings
• Offline submission queue
• Push history

This cannot be undone.`)&&(await I(),alert("All local data has been nuked."),location.reload())});function d(){var e;if(a){if(typeof chrome>"u"||!((e=chrome.storage)!=null&&e.local)){a.innerHTML='<tr><td colspan="4" class="text-ash">chrome.storage not available</td></tr>';return}chrome.storage.local.get(null,o=>{const r=Object.keys(o);if(r.length===0){a.innerHTML='<tr><td colspan="4" class="text-ash">No keys currently stored</td></tr>';return}a.innerHTML=r.map(t=>{const n=o[t],g=Array.isArray(n)?"array":typeof n,i=JSON.stringify(n),p=i.length>1024?`${(i.length/1024).toFixed(1)} KB`:`${i.length} B`,y=t===u.ENCRYPTED_PAT||t===u.CONFIG&&(n==null?void 0:n.pat)?'<span class="text-crimson">SENSITIVE</span>':"PLAIN";return`
          <tr>
            <td><code>${m(t)}</code></td>
            <td>${g}</td>
            <td>${y}</td>
            <td>${p}</td>
          </tr>
        `}).join("")})}}function m(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}});
